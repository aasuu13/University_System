import csv
import os
from typing import List, Dict, Optional

class User:
    """کلاس پایه برای کاربران"""
    def __init__(self, username: str, password: str, role: str):
        self.username = username
        self.password = password
        self.role = role
        self.name = username  # برای نمایش نام در پنل‌ها

    def check_password(self, password: str) -> bool:
        return self.password == password


class Student(User):
    """کلاس دانشجو"""
    def __init__(self, username: str, password: str):
        super().__init__(username, password, "student")
        self.name = username  # می‌توانید نام واقعی را هم اضافه کنید

    def calculate_gpa(self, student_courses: List[Dict]) -> float:
        """
        محاسبه معدل دانشجو
        
        Args:
            student_courses: لیست دروس دانشجو با نمرات
            
        Returns:
            float: معدل دانشجو (در صورت نداشتن نمره، 0 برگردانده می‌شود)
        """
        grades = []
        for course in student_courses:
            grade = course.get('grade')
            if grade and grade != '':
                try:
                    grades.append(float(grade))
                except ValueError:
                    continue
        
        if grades:
            return round(sum(grades) / len(grades), 2)
        return 0.0


class Teacher(User):
    """کلاس استاد"""
    def __init__(self, username: str, password: str):
        super().__init__(username, password, "teacher")
        self.name = username  # می‌توانید نام واقعی را هم اضافه کنید


class Course:
    """کلاس درس"""
    def __init__(self, course_name: str, teacher: str, prerequisites: str = ""):
        """
        Args:
            course_name: نام درس
            teacher: نام استاد (یوزرنیم)
            prerequisites: پیش‌نیازها (به صورت رشته با کاما جدا شده)
        """
        self.course_name = course_name
        self.teacher = teacher
        self.prerequisites = [p.strip() for p in prerequisites.split(',') if p.strip()]
        self.code = f"CRS-{hash(course_name) % 10000:04d}"  # کد خودکار برای درس


class UniversitySystem:
    """کلاس اصلی سیستم مدیریت دانشگاه"""
    
    def __init__(self):
        """مقداردهی اولیه سیستم و بارگذاری داده‌ها"""
        self.users: List[User] = []
        self.courses: List[Course] = []
        self.student_courses: List[Dict] = []
        self.data_path = "data"
        self.load_all_data()

    # ====================== بارگذاری داده‌ها ======================
    
    def load_all_data(self):
        """بارگذاری تمام داده‌ها از فایل‌های CSV"""
        self.load_users()
        self.load_courses()
        self.load_student_courses()

    def load_users(self):
        """بارگذاری کاربران از فایل users.csv"""
        try:
            with open(f"{self.data_path}/users.csv", 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['role'] == 'student':
                        student = Student(row['username'], row['password'])
                        # اگر نام در فایل موجود بود، استفاده کن
                        if 'name' in row and row['name']:
                            student.name = row['name']
                        self.users.append(student)
                    else:
                        teacher = Teacher(row['username'], row['password'])
                        if 'name' in row and row['name']:
                            teacher.name = row['name']
                        self.users.append(teacher)
            print(f"✅ {len(self.users)} کاربر لود شد")
        except FileNotFoundError:
            print("❌ فایل users.csv پیدا نشد!")

    def load_courses(self):
        """بارگذاری دروس از فایل courses.csv"""
        try:
            with open(f"{self.data_path}/courses.csv", 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    self.courses.append(Course(
                        row['course_name'],
                        row['teacher'],
                        row.get('prerequisites', '')
                    ))
            print(f"✅ {len(self.courses)} درس لود شد")
        except FileNotFoundError:
            print("❌ فایل courses.csv پیدا نشد!")

    def load_student_courses(self):
        """بارگذاری نمرات دانشجویان از فایل student_courses.csv"""
        try:
            with open(f"{self.data_path}/student_courses.csv", 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                self.student_courses = list(reader)
            print(f"✅ {len(self.student_courses)} رکورد نمره لود شد")
        except FileNotFoundError:
            print("❌ فایل student_courses.csv پیدا نشد!")

    # ====================== ذخیره‌سازی داده‌ها ======================
    
    def save_student_courses(self):
        """ذخیره تغییرات انتخاب واحد و نمرات در فایل CSV"""
        try:
            # ایجاد پوشه data اگر وجود ندارد
            os.makedirs(self.data_path, exist_ok=True)
            
            fieldnames = ['username', 'course_name', 'grade']
            with open(f"{self.data_path}/student_courses.csv", 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(self.student_courses)
            print("✅ تغییرات نمرات ذخیره شد")
        except Exception as e:
            print(f"❌ خطا در ذخیره فایل: {e}")

    def save_all_data(self):
        """ذخیره تمام داده‌ها (برای استفاده در آینده)"""
        self.save_student_courses()

    # ====================== متدهای احراز هویت ======================
    
    def login(self, username: str, password: str) -> Optional[User]:
        """
        احراز هویت کاربر
        
        Args:
            username: نام کاربری
            password: رمز عبور
            
        Returns:
            User یا None: در صورت موفقیت، شیء کاربر برگردانده می‌شود
        """
        for user in self.users:
            if user.username == username and user.check_password(password):
                print(f"✅ لاگین موفق: {username} ({user.role})")
                return user
        print(f"❌ لاگین ناموفق: {username}")
        return None

    # ====================== متدهای کاربری ======================
    
    def get_user(self, username: str) -> Optional[User]:
        """
        دریافت کاربر بر اساس نام کاربری
        
        Args:
            username: نام کاربری
            
        Returns:
            User یا None: در صورت یافت شدن، شیء کاربر برگردانده می‌شود
        """
        for user in self.users:
            if user.username == username:
                return user
        return None

    def get_all_students(self) -> List[Student]:
        """دریافت لیست تمام دانشجویان"""
        return [user for user in self.users if user.role == "student"]

    def get_all_teachers(self) -> List[Teacher]:
        """دریافت لیست تمام اساتید"""
        return [user for user in self.users if user.role == "teacher"]

    # ====================== متدهای درسی ======================
    
    def get_teacher_courses(self, teacher_username: str) -> List[Course]:
        """
        دریافت لیست دروس یک استاد
        
        Args:
            teacher_username: نام کاربری استاد
            
        Returns:
            List[Course]: لیست دروس استاد
        """
        return [c for c in self.courses if c.teacher == teacher_username]

    def get_student_courses(self, username: str) -> List[Dict]:
        """
        دریافت لیست دروس یک دانشجو با نمرات
        
        Args:
            username: نام کاربری دانشجو
            
        Returns:
            List[Dict]: لیست دروس با نمرات
        """
        return [c for c in self.student_courses if c.get('username') == username]

    def get_course_students(self, course_name: str) -> List[Dict]:
        """
        دریافت لیست دانشجویان یک درس
        
        Args:
            course_name: نام درس
            
        Returns:
            List[Dict]: لیست دانشجویان با نمرات
        """
        return [s for s in self.student_courses if s['course_name'] == course_name]

    def get_student_grade(self, username: str, course_name: str) -> Optional[float]:
        """
        دریافت نمره یک دانشجو در یک درس خاص
        
        Args:
            username: نام کاربری دانشجو
            course_name: نام درس
            
        Returns:
            float یا None: نمره دانشجو یا None اگر ثبت نشده باشد
        """
        for record in self.student_courses:
            if record['username'] == username and record['course_name'] == course_name:
                grade = record.get('grade')
                if grade and grade != '':
                    try:
                        return float(grade)
                    except ValueError:
                        return None
                return None
        return None

    def set_grade(self, username: str, course_name: str, grade: float) -> bool:
        """
        ثبت نمره برای دانشجو در یک درس
        
        Args:
            username: نام کاربری دانشجو
            course_name: نام درس
            grade: نمره (عدد بین 0 تا 20)
            
        Returns:
            bool: موفقیت یا شکست عملیات
        """
        for record in self.student_courses:
            if record['username'] == username and record['course_name'] == course_name:
                record['grade'] = grade
                self.save_student_courses()
                return True
        return False

    # ====================== متدهای آماری و گزارش‌گیری ======================
    
    def calculate_gpa(self, username: str) -> float:
        """
        محاسبه معدل یک دانشجو
        
        Args:
            username: نام کاربری دانشجو
            
        Returns:
            float: معدل دانشجو
        """
        student = self.get_user(username)
        if not student or student.role != "student":
            return 0.0
        
        courses = self.get_student_courses(username)
        return student.calculate_gpa(courses)

    def get_ranking(self) -> List[tuple]:
        """
        دریافت رتبه‌بندی دانشجویان بر اساس معدل
        
        Returns:
            List[tuple]: لیست تاپل‌های (نام کاربری، معدل) به ترتیب نزولی
        """
        students = self.get_all_students()
        ranking = []
        
        for student in students:
            gpa = self.calculate_gpa(student.username)
            ranking.append((student.username, gpa))
        
        # مرتب‌سازی بر اساس معدل (نزولی)
        ranking.sort(key=lambda x: x[1], reverse=True)
        return ranking

    def get_all_grades_report(self, course_name: str = None) -> Dict:
        """
        دریافت گزارش نمرات
        
        Args:
            course_name: نام درس (اختیاری) - اگر None باشد، تمام دروس را گزارش می‌دهد
            
        Returns:
            Dict: گزارش نمرات شامل میانگین، کمترین و بیشترین نمره
        """
        if course_name:
            students = self.get_course_students(course_name)
            grades = []
            for s in students:
                grade = s.get('grade')
                if grade and grade != '':
                    try:
                        grades.append(float(grade))
                    except ValueError:
                        continue
            
            return {
                'course': course_name,
                'count': len(grades),
                'average': round(sum(grades) / len(grades), 2) if grades else 0,
                'min': min(grades) if grades else None,
                'max': max(grades) if grades else None
            }
        else:
            # گزارش تمام دروس
            report = {}
            for course in self.courses:
                report[course.course_name] = self.get_all_grades_report(course.course_name)
            return report


# برای اجرای تست
if __name__ == "__main__":
    # ایجاد نمونه برای تست
    system = UniversitySystem()
    print("\n" + "="*50)
    print("📊 سیستم مدیریت دانشگاه - تست اولیه")
    print("="*50)
    
    # نمایش کاربران
    print(f"\n👥 تعداد کاربران: {len(system.users)}")
    for user in system.users:
        print(f"  - {user.username} ({user.role})")
    
    # نمایش دروس
    print(f"\n📚 تعداد دروس: {len(system.courses)}")
    for course in system.courses:
        prereq = course.prerequisites[0] if course.prerequisites else "ندارد"
        print(f"  - {course.course_name} (استاد: {course.teacher}, پیش‌نیاز: {prereq})")
    
    # نمایش نمرات
    print(f"\n🎯 تعداد نمرات ثبت شده: {len(system.student_courses)}")
    
    # نمایش رتبه‌بندی
    print(f"\n🏆 رتبه‌بندی دانشجویان:")
    ranking = system.get_ranking()
    for i, (username, gpa) in enumerate(ranking, 1):
        print(f"  {i}. {username} - معدل: {gpa}")